import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescription-add',
  templateUrl: './prescription-add.component.html',
  styleUrls: ['./prescription-add.component.css']
})
export class PrescriptionAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

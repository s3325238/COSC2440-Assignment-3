import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescription-detail',
  templateUrl: './prescription-detail.component.html',
  styleUrls: ['./prescription-detail.component.css']
})
export class PrescriptionDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

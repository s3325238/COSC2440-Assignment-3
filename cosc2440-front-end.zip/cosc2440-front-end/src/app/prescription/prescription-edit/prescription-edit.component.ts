import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prescription-edit',
  templateUrl: './prescription-edit.component.html',
  styleUrls: ['./prescription-edit.component.css']
})
export class PrescriptionEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
